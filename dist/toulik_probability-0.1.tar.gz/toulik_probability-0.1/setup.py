from setuptools import setup

setup(name='toulik_probability',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
